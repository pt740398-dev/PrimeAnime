# Prime Anime

Flutter Android starter for a dark anime discovery and tracking app inspired by the supplied AniTM screenshots. Uses Jikan API for anime metadata and Supabase for optional account/cloud features.

## Features in this foundation
- Home, Explore, Schedule, Watchlist and Profile navigation
- Anime discovery, search, details, ratings, synopsis and poster artwork
- Supabase email/password sign-in and sign-up (requires project keys)
- Supabase SQL schema with row-level security for profiles, watchlists and watch progress
- Local watchlist cache and Android APK GitHub Actions workflow
- Video player component for authorized stream URLs; no scraped or unlicensed streams are bundled

## Backend setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In GitHub repository settings, add Actions secrets `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
4. Run the **Prime Anime APK Build** workflow.
5. Without secrets, the app still runs in metadata/demo mode; account login and cloud sync remain disabled.

For local development:
```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

## Important
Anime metadata is provided by the public Jikan API (MyAnimeList data). Availability and response limits are controlled by that service. This project does not include copyrighted anime video files or scrape streaming sites. Add only licensed/authorized playback URLs to the player integration.
